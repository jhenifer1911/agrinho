let cidadeCor;
let campoCor;
let populacaoCrescimento = 0; // Representa o crescimento da cidade

function setup() {https://editor.p5js.org/ribeiro.rocha.jhenifer/sketches
  createCanvas(800, 600);
  cidadeCor = color(100, 100, 150); // Tons de cinza/azul para a cidade
  campoCor = color(100, 150, 100);  // Tons de verde para o campo
  noStroke();
}

function draw() {
  // Fundo gradual do campo para a cidade
  for (let i = 0; i < height; i++) {
    let inter = map(i, 0, height, 0, 1);
    let c = lerpColor(campoCor, cidadeCor, inter);
    stroke(c);
    line(0, i, width, i);
  }

  noStroke();

  // Representação do Campo
  // Montanhas/colinas no horizonte
  fill(campoCor.levels[0] - 20, campoCor.levels[1] - 20, campoCor.levels[2] - 20, 200); // Mais escuro
  beginShape();
  vertex(0, height * 0.7);
  bezierVertex(width * 0.2, height * 0.6, width * 0.4, height * 0.8, width * 0.6, height * 0.75);
  bezierVertex(width * 0.8, height * 0.7, width, height * 0.8, width, height);
  vertex(0, height);
  endShape(CLOSE);

  // Árvores aleatórias no campo
  fill(50, 100, 50); // Verde escuro para as árvores
  for (let i = 0; i < 10; i++) {
    let x = random(width * 0.1, width * 0.5);
    let y = random(height * 0.75, height * 0.9);
    ellipse(x, y, 15, 30); // Tronco
    ellipse(x, y - 20, 40, 40); // Copa
  }

  // Representação da Cidade
  // Edifícios (retângulos)
  fill(cidadeCor);
  let numEdificios = map(populacaoCrescimento, 0, 100, 5, 20); // Mais edifícios com o crescimento
  for (let i = 0; i < numEdificios; i++) {
    let edificioLargura = random(20, 50);
    let edificioAltura = random(50, 200);
    let edificioX = random(width * 0.5, width - edificioLargura);
    let edificioY = height - edificioAltura - random(0, 50); // Varia a altura da base
    rect(edificioX, edificioY, edificioLargura, edificioAltura);

    // Janelas (quadradinhos amarelos)
    fill(255, 255, 100, 200); // Amarelo claro para as janelas
    for (let j = 0; j < edificioAltura / 20; j++) {
      for (let k = 0; k < edificioLargura / 15; k++) {
        rect(edificioX + 5 + k * 15, edificioY + 5 + j * 20, 8, 12);
      }
    }
    fill(cidadeCor); // Volta para a cor do edifício
  }

  // Interconexão
  // Linhas representando estradas/fluxo
  stroke(150, 150, 0, 150); // Cor de asfalto/terra
  strokeWeight(3);
  line(width * 0.4, height * 0.85, width * 0.6, height * 0.75);
  line(width * 0.3, height * 0.9, width * 0.7, height * 0.8);
  noStroke();

  // "Luzes" da cidade se espalhando um pouco no campo
  fill(255, 200, 0, 50); // Laranja claro, semi-transparente
  ellipse(width * 0.55, height * 0.8, 80 + populacaoCrescimento * 0.5, 60 + populacaoCrescimento * 0.5);

  // Texto para indicar as áreas
  fill(255);
  textSize(24);
  textAlign(LEFT, TOP);
  text("Campo", 20, 20);
  textAlign(RIGHT, TOP);
  text("Cidade", width - 20, 20);

  // Simulação de crescimento da cidade
  populacaoCrescimento = (populacaoCrescimento + 0.1) % 100; // Cresce de 0 a 100 e reinicia
}

function mousePressed() {
  // Ao clicar, você pode adicionar uma "interação"
  // Por exemplo, uma estrela cadente no campo ou um novo edifício na cidade
  console.log("Clicou! Adicione sua própria interação aqui.");
}
